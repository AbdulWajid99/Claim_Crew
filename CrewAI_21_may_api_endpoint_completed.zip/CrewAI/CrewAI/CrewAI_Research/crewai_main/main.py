## Import required libraries

import sys

sys.path.append(
    "G:\My Drive\AI_Lead\Research_N_Development\CrewAI\CrewAI\CrewAI_Research\crewai_main"
)

import os
from crewai import Crew, Process
from crew.crew_1.agents import AIClaimAgents
from crew.crew_1.tasks import AgentClaimTasks
from single_agent.single_agent import AIClaimSingleAgent
from tools.file_io import save_markdown
from langchain_community.llms import HuggingFaceEndpoint
from langchain_community.llms import Ollama
from tools.agent_output_tool import print_agent_output

# from tools.document_ocr_tool import document_processing  ### in django backend

## Initialize Global variables
# from dotenv import load_dotenv
# load_dotenv()
os.environ["OPENAI_API_KEY"] = (
    "testing_dummy_key"  # sk-proj-2mgLnO3sHblJ6VGFtCJET3BlbkFJ9hH85WziIXIkWMtH0w3Q
)
os.environ["SERPER_API_KEY"] = (
    "Your Key"  # serper.dev API key #ad75f02eec2b30bee734e1e261c81e6c17e4f529
)


# Main Crews Class
class AICrew:

    def __init__(self, model, model_name):
        self.model = model
        self.model_name = model_name
        self.claim_content = ""

        # Document database path # change
        self.document_db_root_path = "G:\\My Drive\\AI_Lead\\Research_N_Development\\CrewAI\\CrewAI\\CrewAI_Research\\crewai_main\\static\\Insurance_Data\\"

    # in django
    # def load_claim_content(self):
    #     doc_processing = document_processing(
    #         self.document_path
    #     )  ## doc processing object
    #     doc_results = doc_processing.document_ocr()
    #     document_content = doc_results.get("text")
    #     self.claim_content = document_content
    #     (
    #         print(
    #             "\nData preprocessed: ",
    #             doc_results.get("status"),
    #             "Reason: ",
    #             doc_results.get("reason"),
    #         )
    #         if doc_results.get("status") == False
    #         else print(
    #             "\nData preprocessed: ",
    #             doc_results.get("status"),
    #             "Input data length: ",
    #             len(doc_results.get("text")),
    #         )
    #     )

    def process_claim(self, model_type, claim_content, database_object):

        print(
            "Model Received: \nName: ",
            self.model_name,
            "Model description: ",
            self.model,
        )

        self.claim_content = claim_content

        if (
            not isinstance(self.model, (HuggingFaceEndpoint, Ollama))
            or self.model is None
        ):
            print(
                "Invalid model received. Not a instance of HuggingFaceEndpoint, Using GPT4 API instead"
            )

        ## Switch methods based on input
        if model_type == 0:
            return self.process_claim_concurrent(database_object)
        elif model_type == 1:
            return self.process_claim_single_agent(database_object)

    def process_claim_concurrent(self):

        # Initialize function variables
        results = None

        try:

            # Initialize the agents and tasks objects
            agents = AIClaimAgents()
            tasks = AgentClaimTasks()

            # Instantiate the agents
            categorizer = agents.make_categorizer_agent()
            analyzer = agents.claims_intake_agent()
            validator = agents.claims_validation_agent()
            recommendator = agents.employee_recommendation_agent()

            # Instantiate the tasks
            categorize_claim = tasks.categorize_claim(
                categorizer, self.claim_content, self.database_object
            )
            research_info = tasks.research_info_for_claim(
                analyzer, self.claim_content, categorize_claim
            )
            validate_claim_task = tasks.validate_claim(
                validator, self.claim_content, categorize_claim, research_info
            )
            recommendator_task = tasks.task_employee_recommendation(
                recommendator, self.claim_content
            )

            # Form the crew
            crew = Crew(
                agents=[
                    categorizer,
                ],  # categorizer, analyzer, validator, recommendator
                tasks=[
                    categorize_claim,
                ],  # categorize_claim, research_info, validate_claim_task recommendator_task
                verbose=2,  # "verbosity," which refers to the level of detail or output provided by a program or process. 0 1 2 3
                process=Process.hierarchical,
                # process=Process.sequential,  # Sequential process will have tasks executed one after the other and the outcome of the previous one is passed as extra content into this next.
                manager_llm=self.model,
                full_output=True,
                share_crew=False,
                step_callback=lambda x: print_agent_output(x, "MasterCrew Agent"),
            )

            # Kick off the crew's work
            results = crew.kickoff()

            # Print the results
            print("\nClaim Crew Work Finalized Successfully!")
            print(crew.usage_metrics)
            return results

        except Exception as e:
            print("An error occurred during ClaimCrew:", str(e))
            return None

    def process_claim_single_agent(self, database_object):
        single_agent = AIClaimSingleAgent(
            model=self.model,
            database_object=database_object,
            model_name=self.model_name,
            claim_content=self.claim_content,
            document_db_root_path=self.document_db_root_path,
        )
        return single_agent.single_agent_main()
