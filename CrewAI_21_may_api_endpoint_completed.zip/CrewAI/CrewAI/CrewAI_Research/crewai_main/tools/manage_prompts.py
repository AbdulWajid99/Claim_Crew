import json

## Append project directoty path
import sys

sys.path.append(
    "G:\My Drive\AI_Lead\Research_N_Development\CrewAI\CrewAI\CrewAI_Research\crewai_main"
)


class Prompts:
    def __init__(self, prompt_agent):
        self.prompt_agent = prompt_agent

    def load_prompts(self):
        try:
            with open("prompts/prompts.json") as f:
                prompts = json.load(f)
            if prompts:
                agent_prompts = prompts.get(self.prompt_agent)
            else:
                raise
        except Exception as e:
            print("An error occurred during loading prompts:", str(e))
            return None

        return agent_prompts

    def get_prompt(self, model_name):
        
        return self.prompts.get(model_name, "")

    def add_prompt(self, model_name, prompt):
        self.prompts[model_name] = prompt
        self.save_prompts()

    def update_prompt(self, model_name, prompt):
        if model_name in self.prompts:
            self.prompts[model_name] = prompt
            self.save_prompts()

    def delete_prompt(self, model_name):
        if model_name in self.prompts:
            del self.prompts[model_name]
            self.save_prompts()

    def save_prompts(self):
        with open("../prompts/prompts.json", "w") as f:
            json.dump(self.prompts, f, indent=4)

    def list_prompts(self):
        return list(self.prompts.keys())
