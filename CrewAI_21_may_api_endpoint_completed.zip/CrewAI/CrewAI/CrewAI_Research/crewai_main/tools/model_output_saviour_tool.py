import random
import pathlib
import datetime


class OutputSaver:
    def __init__(self, model_name, claim_content, database_object):
        self.output_dir = "Results"
        self.inference_number = random.randint(100, 999)
        self.output_file = f"{self.output_dir}/{model_name}/inference_{self.inference_number}_{self.get_time('In minutes')}.txt"
        self.output_file = pathlib.Path(self.output_file)
        # Create the directory and file if they don't exist
        self.output_file.parent.mkdir(parents=True, exist_ok=True)
        self.output_file.touch(exist_ok=True)

        self.save_inference_output(model_name, claim_content, database_object)

    def get_time(self, type=None):
        if type == "In minutes":
            return datetime.datetime.now().strftime("%d_%H_%M")
        else:
            return datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    def save_inference_output(self, model_name, claim_content, database_object):

        # Formatting result
        results = f"""Inference initiated on: {self.get_time()}\n
        Received data from user: {claim_content}\n\n
        Database record: {database_object}\n
        """

        with open(self.output_file, "w") as f:
            f.write(str(results))

    def save_agent_output(self, agent_name, results):
        # append text to previously saved output file

        results = f"""{agent_name} responded on: {self.get_time()}\n
        Response results: {results}\n\n
        
        """

        with open(self.output_file, "a") as file:
            file.write(results + "\n")
