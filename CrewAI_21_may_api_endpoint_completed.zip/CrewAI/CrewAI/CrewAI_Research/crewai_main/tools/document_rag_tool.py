## Import required modules
import docx


class DocumentRag:
    def __init__(self):
        pass

    def extract_word_data(self, file_path):
        doc = docx.Document(file_path)
        data = []
        for para in doc.paragraphs:
            data.append(para.text)

        data = " ".join(data)
        return data
