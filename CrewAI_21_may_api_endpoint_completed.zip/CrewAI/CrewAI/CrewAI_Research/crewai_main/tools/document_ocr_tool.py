import io
import os
import fitz  # PyMuPDF for PDF parsing
import pdf2image
import pytesseract
from PIL import Image
from docx import Document
from paddleocr import PaddleOCR
os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION'] = 'python'

# Path to the Tesseract executable
pytesseract.pytesseract.tesseract_cmd = r'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'

# Specific windows paths
#win_poppler_path = "G:\\My Drive\\AI_Lead\\Research_N_Development\\CrewAI\\CrewAI\CrewAI_Research\\crewai_main\\windows_tools\\Release-24.02.0-0.zip"
#win_poppler_path = "G:\\My Drive\\AI_Lead\\Research_N_Development\\CrewAI\\CrewAI\\CrewAI_Research\\rewai_main\\tools\\windows_tools\\poppler-24.02.0\\Library\\bin"



# Process the input documents 
class document_processing():    

    def __init__(self, file_path):
        self.file_path = file_path
        self.status = {'status' : False, 'reason': 'Not processed yet'}      
        self.file_extension = os.path.splitext(self.file_path )[1].lower() # Get the file extension
        self.paddle_obj = PaddleOCR()
        
    def text_preprocessing(self, text):

        """
        Clean and preprocess text.

        Args:
            text (str): The input text to be cleaned.

        Returns:
            str: The cleaned text.

        """
        # Define a dictionary for character replacements
        replacements = {
        #    '-': ' ',
            # '|': '',
            # '[': '',
            # ']': '',
            # '}': '',
            # '{': '',
            # '__': '',
            # '_': '',
            # '——': '',
            # '—': '',
            # "\'": '',
            # "'": '',
            # "”": '',
            # "‘": '',
            # '"': '',
            # "°": '',
            # '=': '',
            # '@': '&',
            # "£": 'E',
            # "€": 'E',
            # "«": '',
            # ":": '',
            # ";": '',
            # "»": '',
            # "¢": '',
            # "#": '',
            # "~": '',
            # "..": '',
            # "“": '',
            # '″': '',
            # "(s)": 's',
            # "“": '',
        }
        
        #Lowercase
        #text = text.lower()

        # Apply replacements
        for old, new in replacements.items():
            text = text.replace(old, new)

        # Clean extra spaces and remove lines
       # text = ' '.join(text.split())
        #text = '\n'.join([line.strip() for line in text.split('\n') if line.strip() != ''])# complete remove new empty lines
        text = '\n'.join([line.strip() for i, line in enumerate(text.split('\n')) if line.strip() != '' or (i > 0 and text.split('\n')[i-1].strip() != '')]) # leave one line space

        text = text.strip()
    
        return text
        
    def paddle_ocr(self, image):
        try:
            if isinstance(image, str):
                result = self.paddle_obj.ocr(image)# det=False
                text = '\n'.join([word[1][0] for line in result for word in line])
            else:
                img_byte_arr = io.BytesIO()
                image.save(img_byte_arr, format='PNG')
                image_bytes = img_byte_arr.getvalue()
                result = self.paddle_obj.ocr(image_bytes)# det=False
                text = '\n'.join([word[1][0] for line in result for word in line])
            text = self.text_preprocessing(text)
        except Exception as e:
            print("Error in paddle OCR: ", e)
            text=''
        return text


    def tesseract_ocr(self, image):
        try:
            if isinstance(image, str):
                # Open the image file
                with Image.open(image) as img:
                    # Perform OCR on the image
                    text = pytesseract.image_to_string(img)
            else:
                text = pytesseract.image_to_string(image)
                
            text = self.text_preprocessing(text)
        except Exception as e:
            print("Error in tesseract OCR: ", e)
            text=''
        return text
        
    def image_ocr(self, image, ocr_type=1):
        if ocr_type == 0:
            text = self.paddle_ocr(image)
            # If paddle fails
            if not text:
                text = self.tesseract_ocr(image)
            return text
        elif ocr_type == 1:
            text = self.tesseract_ocr(image)
            # If tesseract fails
            if not text:
                text = self.paddle_ocr(image)
            return text
        else:
            print("Unsupported OCR type, Please select between paddle(0) and tesseract(1) ")
            return None

    def document_selectable_ocr(self, file_path):
        text = ''
        # OCR - Selectable text
        with fitz.open(file_path) as file:
            for page_num in range(len(file)):
                page = file.load_page(page_num)
                text += page.get_text()
        text = self.text_preprocessing(text)
        return text
    
    def document_scanned_ocr(self, file_path, doc_type):
        text = ''
        if doc_type=='pdf':
            #Convert pdf to image
            pages = pdf2image.convert_from_path(file_path, 300)# set dpi=300, first_page = 1, last_page = 1)
            for index, image in enumerate(pages):
                text += self.image_ocr(image)
                
        elif doc_type=='word':
    
            try:
                # Open the Word document
                doc = Document(file_path)
                # Extract images from the document
                images = []
                for rel in doc.part.rels.values():
                    if "image" in rel.target_ref:
                        image_data = rel.target_part.blob
                        # Convert image data to PIL Image
                        img = Image.open(io.BytesIO(image_data))
                        images.append(img)
                # Perform OCR on each image
                for img in images:
                    text_temp = self.image_ocr(img)
                    text += text_temp + "\n"
                    
            except Exception as e:
                print("Error in processing Word document: ", e)
            
        return text
    

    def main_ocr(self, file_path, doc_type, ocr_type=0):
        
        """
        paddle = 0
        tesseract = 1 
        """
        
        text = ''

        if doc_type == 'image':
            text = self.image_ocr(file_path)
        
        elif doc_type == 'word':
            # Selectable text OCR
            text = self.document_selectable_ocr(file_path)
            
            if len(text)<=10:
                print("No text found, Checking scanned word doc:")   
                text = self.document_scanned_ocr(file_path, doc_type) 
    
        elif doc_type == 'pdf':
            
            # Selectable text OCR
            text = self.document_selectable_ocr(file_path)
            
            if len(text)<=10:
                print("No text found, Checking scanned pdf:")   
                text = self.document_scanned_ocr(file_path, doc_type) 
    
        return text

    def document_ocr(self):

        # Check if the documnet exists
        if not os.path.exists(self.file_path):
            print("Document not found.")
            self.status['reason'] = 'Document not found'
            return self.status
        
        if self.file_extension == '.pdf':
            print("Received PDF file extension!")
            
            text = self.main_ocr(self.file_path, 'pdf') 
     
            if text:
                self.status['status'] = True
                self.status['reason'] = 'PDF document text extracted'
                self.status['text'] = text
                
            else:
                self.status['status'] = False
                self.status['reason'] = 'PDF document extraction failed'
                self.status['text'] = ''
                
            return self.status
        
        
        elif self.file_extension == '.docx':
            print("Received word file extension!")

            text = self.main_ocr(self.file_path, 'word') 

            
            if text:
                self.status['status'] = True
                self.status['reason'] = 'Word document text extracted'
                self.status['text'] = text
                
            else:
                self.status['status'] = False
                self.status['reason'] = 'Word document extraction failed'
                self.status['text'] = ''
                
            return self.status     
                    
            return images_text
        
        elif self.file_extension in ['.jpg', '.jpeg', '.png', '.tiff', '.bmp']:
            print("Received image file extension!")
        
            text = self.main_ocr(self.file_path, 'image') 
     
            if text:
                self.status['status'] = True
                self.status['reason'] = 'Image document text extracted'
                self.status['text'] = text
                
            else:
                self.status['status'] = False
                self.status['reason'] = 'Image document extraction failed'
                self.status['text'] = ''
                
            return self.status
        
        else:
            self.status['status'] = False
            self.status['reason'] = 'Unsupported file format. Supported formats are images, pdf and word documents.'
            self.status['text'] = ''
                
            return self.status
        
        
        return self.status
    
    
    