## Import required libraries
import json
import re


class ModelResponseProcessing:
    def __init__(self):
        pass

    def process_response(self, agent, response):

        if agent == "single_agent_categorizer":
            return self.single_agent_categorizer_process(response)

        elif agent == "single_agent_summarizer":
            return self.single_agent_summarizer_process(response)

        elif agent == "single_agent_validator":
            return self.single_agent_validator_process(response)

    def text_cleaning(self, text):
        # Remove newline characters
        text = text.replace("\n", " ")

        # Remove single quotes
        text = text.replace("'", '"')  # problem with ' in response

        # Remove square brackets
        text = text.replace("[", "{")
        text = text.replace("]", "}")

        # Remove HTML tags
        text = re.sub(r"<.*?>", "", text)

        # Remove punctuation
        # text = re.sub(r"[^\w\s]", "", text) - will remove brackets, comma's etc

        # Remove extra whitespace
        text = re.sub(r"\s+", " ", text)

        # Convert to lowercase
        # text = text.lower()

        # Remove stopwords
        # stopwords = ["the", "and", "a", "an", "is", "in", "that", "for", "it", "with", "as", "on", "at", "by"]
        # text = " ".join([word for word in text.split() if word not in stopwords])

        # Lemmatize words
        #

        # Concatenate all text into a single line
        text = " ".join(text.splitlines())

        return text

    def single_agent_categorizer_process(self, response):

        print("Before processing categorizer response: ", response)

        # Extract the categorization result
        claim_type = None
        time_taken = None
        explanation = None

        # Convert to json directly
        try:
            response = json.loads(self.text_cleaning(response))
        except Exception as e:
            print(
                "An error occurred response json conversion, Retrying with different method!",
                str(e),
            )
            # Extract the JSON object from the response string
            json_response = re.search(r"{.*}", response).group()
            response = json.loads(self.text_cleaning(json_response))

        claim_type = response.get("claim_type")
        time_taken = response.get("time_taken")
        explanation = response.get("explanation")

        # Parse the response string
        # lines = response.split("\n")
        # print(lines)
        # for line in lines:
        #     if line.startswith("claim_type`:"):
        #         claim_type = line.split(":")[1].strip()
        #     elif line.startswith("time_taken`:"):
        #         time_taken = line.split(":")[1].strip()
        #     elif line.startswith("explanation`:"):
        #         explanation = line.split(":")[1].strip()

        # Return the processed response
        return {
            "claim_type": claim_type,
            "time_taken": time_taken,
            "explanation": explanation,
        }

    def single_agent_summarizer_process(self, response):

        print("Before processing summarizer response: ", response)

        # Extract the categorization result
        summary = None
        time_taken = None
        explanation = None

        # Convert to json directly
        try:
            response = json.loads(self.text_cleaning(response))
        except Exception as e:
            print(
                "An error occurred response json conversion, Retrying with different method!",
                str(e),
            )
            # Extract the JSON object from the response string
            json_response = re.search(r"{.*}", response).group()
            response = json.loads(self.text_cleaning(json_response))

        summary = response.get("summary")
        time_taken = response.get("time_taken")
        explanation = response.get("explanation")

        # Return the processed response
        return {
            "summary": summary,
            "time_taken": time_taken,
            "explanation": explanation,
        }

    def single_agent_validator_process(self, response):

        print("Before processing validator response: ", response)

        # Extract the categorization result
        validation = None
        time_taken = None

        # Convert to json directly
        try:
            response = json.loads(self.text_cleaning(response))
        except Exception as e:
            print(
                "An error occurred response json conversion, Retrying with different method!",
                str(e),
            )

        # Extract the JSON object from the response string
        try:
            json_response = re.search(r"{.*}", response).group()
            response = json.loads(self.text_cleaning(json_response))
        except Exception as e:
            print(
                "An error occurred response json conversion2!",
                str(e),
            )

        if isinstance(validation, dict):
            validation = response.get(
                "validation", "No validations found!/Retry, process interrupted!"
            )
            time_taken = response.get("time_taken", "Few mins")
        elif isinstance(validation, str) and len(response) > 5:
            validation = response
            time_taken = "Few mins"

        # Return the processed response
        return {
            "validation": validation,
            "time_taken": time_taken,
        }
