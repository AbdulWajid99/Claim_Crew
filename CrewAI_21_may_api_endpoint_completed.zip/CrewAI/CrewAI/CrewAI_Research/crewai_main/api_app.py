# Author : Abdul Wajid

# Import required modules
import sys
import json
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse  # Correct import for JSONResponse

from langchain_community.llms import Ollama

## Append project directory path
sys.path.append(
    "G:\My Drive\AI_Lead\Research_N_Development\CrewAI\CrewAI\CrewAI_Research\crewai_main"  # Change
)

# Import project libraries
from main import AICrew

# Initialize the fastapp app
app = FastAPI()


# ------ Required -------

#### Load model of your choice
# Send model null to use gpt4 API end point

# Using Local models through Ollama
model_name = "llama3"  # mistral # llama3 #gemma
model_instance = Ollama(model=model_name)  # llama3 # mistral
# model_instance = None # To use gpt4 api

# ------ Required -------

# Model type:
# 0 - Using Crew(Multiple AI agents)
# 1 - Use custom crew

#### Main crew interface


# llama3 v1

# Call crew

AICrewObj = AICrew(model_instance, model_name)  # Crew object


@app.get("/")
async def api_status(request: Request):
    # Your response data here
    data = {"message": "API Status endpoint! - Connection Success!"}
    return JSONResponse(content=data)


# @app.get("/crew-inference")
# async def api_status(request: Request):
#     # Your response data here
#     data = {"message": "API Status endpoint! - Connection Success!"}
#     return JSONResponse(content=data)


@app.get("/custom-crew-endpoint")
async def custom_crew_endpoint(request: Request):

    body = await request.body()
    json_body = json.loads(body.decode("utf-8"))

    model_type = json_body.get("model_type", 0)
    claim_content = json_body.get("text", 0)
    database_object = json_body.get("db_object", 0)

    print(
        f"Successfully received: Model Type: {model_type} \nReceived data from user: {claim_content}\nMatched database record: {database_object}"
    )

    claim_results = AICrewObj.process_claim(
        model_type, claim_content, database_object
    )  # Call Crew

    if claim_results:
        print(claim_results)

    # Your response data here
    data = {
        "message": "Success!",
        "claim_results": claim_results,
    }
    return JSONResponse(content=data)


if (
    __name__ == "__main__"
):  # uvicorn app:app --host 172.17.0.2 --port 8000 uvicorn api_app:app --reload
    # uvicorn.run(app, host = "http://10.0.0.23:8888/", port = 8000)uvicorn app:app --host 0.0.0.0 --port 8000
    uvicorn.run("api_app:app", host="127.0.0.1", port=5000, log_level="info")

    # # Start uvicorn server in a separate thread
    # loop = asyncio.new_event_loop()
    # asyncio.set_event_loop(loop)
    # server_task = loop.create_task(run_server())
