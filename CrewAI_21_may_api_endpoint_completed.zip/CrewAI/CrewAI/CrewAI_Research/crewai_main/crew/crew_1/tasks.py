## Import required libraries


from datetime import datetime
from crewai import Task


class AgentClaimTasks:

    def __init__(self):
        pass

    def categorize_claim(self, agent, claim_content, database_object):
        ### Check for data received from database
        database_object = (
            "No data regarding this document in our database!"
            if not database_object
            else database_object
        )
        return Task(
            description=f"""Conduct a comprehensive analysis of the claim provided and categorize into 
            one of the following categories:
            random_claim_document - used when received document is a claim document but doesn't fit to be a specific claim type 
            property_damage_claim - used when document is a claim document and it mentions some type of property damage 
            health_insurance_claim - used when document is a claim document and it mentions health related claim 
            auto_insurance_claim -  used when document is a claim document and it mentions auto or vehicle related claim  
            life_insurance_claim - used when document is a claim document and it mentions life related claim 
            not_claim - used when document is not a claim document or it doesn't relate to any other category  
            CLAIM CONTENT:\n\n {claim_content} \n\n
            
            CLAIM RELATED INFORMATION WE HAD IN OUR DATABASE: {database_object} \n\n 
            Output a single category only and reply within 60 seconds and time taken by you to categorize it
            
            """,
            expected_output="""A single category for the type of claim from the types ('random_claim_document', 'property_damage_claim', 'health_insurance_claim', 'auto_insurance_claim', 'life_insurance_claim', 'not_claim') 
            eg:
            {"claim_type" : "life_insurance_claim", time_taken: 3mins 2 seconds} 
            """,
            output_file=f"claim_category.txt",
            agent=agent,
        )

    # def task_claims_intake(self, agent):
    #     return Task(
    #         description="Collect claims forms and accompanying documentation from clients, enter data into the system, and ensure all necessary information is complete and accurate",
    #         agent=agent,
    #         async_execution=True,
    #         expected_output="""A list of top 3 most important collected claims forms
    #         and supporting documentation which includes a summary of the data entered into the system
    #         for each claim a validation result indicating whether all necessary information is complete and accurate for each claim
    #             Example Output:
    #             [
    #                 {  'claim': 'Motor Claim Form',
    #                 'document name': 'John_Doe_Claim_Form.pdf',
    #                 'summary': 'Crashed in the grocery store on...'
    #                 },
    #                 {{...}}
    #             ]
    #         """,
    #     )

    def research_info_for_claim(self, agent, claim_content, categorize_claim):
        return Task(
            description=f"""Conduct a comprehensive analysis of the claim provided and the category 
            provided and search the claim to find info needed to respond the analysis or search the document using tool to find info needed to respond the analysis 

            CLAIM CONTENT:\n\n {claim_content} \n\n
            Only provide the analysis needed DONT try to do anything else""",
            expected_output="""A set of most important headings, paragraphs, tables etc useful info for the claim 
            or clear instructions that no useful material was found to create the analysis. and reply within 60 seconds""",
            context=[categorize_claim],
            output_file=f"research_info.txt",
            agent=agent,
        )

    # def task_claims_analysis(self, agent, context):
    #     return Task(
    #         description="Analyze claims data to identify trends, patterns, and potential fraud",
    #         agent=agent,
    #         async_execution=True,
    #         context=context,  # Feed output of previous task in this task
    #         expected_output="""A markdown-formatted analysis for each claim , including a rundown, detailed bullet points,
    #             and a "Why it is fraud or not" section. There should be at least 5 major claim headings, each following the proper format.
    #             Example Output:
    #             '##   Trends and Patterns\n\n
    #             **The Rundown:
    #             ** Frequency of Claims by Type...\n\n
    #             **Potential Fraud Identification:**\n\n
    #             - Claim 1: John Doe (accident claim with inconsistent documentation)...\n\n
    #             **Why it is fraud or not:** This is...\n\n'
    #         """,
    #     )

    def validate_claim(self, agent, claim_content, categorize_claim, research_info):
        return Task(
            description=f"""Conduct a comprehensive analysis of the claim provided, the category provided
            and the info provided from the research specialist to declare it as valid or not. 

            Write one of the following validation categorize: 
            valid_claim - used when the claim is valid and is eligible of the claim under the policy terms 
            not_valid_claim - used when the claim is not valid and is not eligible of the claim under the policy terms 
              

            If useful use the info provided from the research specialist in the claim. 

            If no useful info was provided from the research specialist then say you are not able to validate this claim but don't make up info. 

            CLAIM CONTENT:\n\n {claim_content} \n\n
            Output a single category only and reply within 60 seconds""",
            expected_output="""A single category for the type of validation claim from the types ('valid_claim', 'not_valid_claim') 
            eg:
            'not_valid_claim' 
            """,
            context=[categorize_claim, research_info],
            agent=agent,
            output_file=f"claim_validation.txt",
        )

    # def task_claims_validation(self, agent, context, callback_function):
    #     return Task(
    #         description="Check the policy database to confirm coverage and terms, and validate claim details against policy conditions",
    #         agent=agent,
    #         context=context,
    #         expected_output="""A complete newsletter in markdown format, with a consistent style and layout.
    #             Example Output:
    #             '# Top policies from the abc database:\\n\\n
    #             - Claim ...
    #         """,
    #         callback=callback_function,  # After execution og this task call the call back function
    #     )

    def task_employee_recommendation(self, agent, claim_content):
        return Task(
            description=f"""
            Conduct a optimzed analysis of the employee's/adjuster list provided, match them with the category provided
            and the info provided from the claim content itself to recommend best match profiles. 
            
            Recommend employees for claims processing based on their expertise 
            and workload based on the claim content and claim category
        
            The claim category : {'auto_insurance_claim'}
            CLAIM CONTENT:\n\n {claim_content} \n\n
            Output a single best matched employee only and reply within 60 seconds
            """,
            expected_output=f"""
            
            The Output MUST have the following markdown format:
                ```
                ## [Employee Name]
                - Relevant expertise
                - Current workload
                ```
                Make sure that it does and if it doesn't, rewrite it accordingly.
                """,
            # async_execution=True,
            # context=[],# Feed output of previous task in this task
            agent=agent,
            output_file=f"adjuster_recommendation.txt",
        )
