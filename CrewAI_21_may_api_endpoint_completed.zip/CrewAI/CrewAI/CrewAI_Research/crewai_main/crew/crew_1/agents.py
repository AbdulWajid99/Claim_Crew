## Import required libraries

import os
from crewai import Agent
from crewai_tools import (
    DirectoryReadTool,
    FileReadTool,
    SerperDevTool,
    WebsiteSearchTool,
    DOCXSearchTool,
)

# from tools.search_tools import SearchTools
from tools.agent_output_tool import print_agent_output

# from langchain.agents import Tool
# from langchain.agents import load_tools

os.environ["OPENAI_API_KEY"] = (
    "testing_dummy_key"  # sk-proj-2mgLnO3sHblJ6VGFtCJET3BlbkFJ9hH85WziIXIkWMtH0w3Q
)


# Instantiate tools
# file_tool = FileReadTool().
# Initialize the tool with a specific DOCX file, so the agent can only search the content of the specified DOCX file
doc_tool = DOCXSearchTool(
    docx="G:\\My Drive\\AI_Lead\\Research_N_Development\\CrewAI\\CrewAI\\CrewAI_Research\\Data\\Rules_Validations\\Claim_Adjusters_List.docx"
)


class AIClaimAgents:

    def __init__(self):
        self.process_steps = ["Initialized!"]

    # def claims_intake_agent(self):
    #     return Agent(
    #         role="Claims Intake Specialist",
    #         goal="Efficiently collect and record incoming claims data",
    #         backstory="""A meticulous and organized professional adept at
    #         capturing all relevant details from incoming claims and initiating the processing chain""",
    #         allow_delegation=False,  # shifting responsibilty to the ai agent # enable collaboration between agent
    #         verbose=True,  # be expressive
    #         # tools=[search_tool]
    #         max_iter=15,  # not to endup in endless loop
    #     )

    def make_categorizer_agent(self):
        return Agent(
            role="Claim Categorizer Agent",
            goal="""take in a claim document from a human that has to be analyzed after categorize it 
            into one of the following categories: 
            random_claim_document - used when received document is a claim document but doesn't fit to be a specific claim type 
            property_damage_claim - used when document is a claim document and it mentions some type of property damage 
            health_insurance_claim - used when document is a claim document and it mentions health related claim 
            auto_insurance_claim -  used when document is a claim document and it mentions auto or vehicle related claim  
            life_insurance_claim - used when document is a claim document and it mentions life related claim 
            not_claim - used when document is not a claim document or it doesn't relate to any other category  
            """,
            backstory="""You are a detail-oriented analyst who excels at understanding and examining claims data
            and are able to categorize it in a useful way no matter what and reply within 60 seconds""",
            verbose=True,
            allow_delegation=False,
            max_iter=5,  # not to endup in endless loop
            memory=True,
            step_callback=lambda x: print_agent_output(x, "Claim Categorizer Agent"),
        )

    def claims_intake_agent(self):
        return Agent(
            role="Info Researcher Agent",
            goal="""take in a claim from a human that has to be analyzed with respect to the category 
            that the categorizer agent gave it and decide what information you need to search for the claim analysis to generate 
            the claim analysis report in a thoughtful and helpful way.
            If you don't think a search will help just reply 'NO SEARCH NEEDED'
            If you don't find any useful info just reply 'NO USEFUL RESEARCH FOUND'
            otherwise reply with the analysis you did that is useful for the claim viewer
            """,
            backstory="""You are a master at understanding and caturing all relevant information from incoming claims to write a decent analysis that 
            will help the claim reviewer and reply within 60 seconds""",
            verbose=True,
            max_iter=5,
            allow_delegation=False,
            memory=True,
            # tools=[search_tool],
            step_callback=lambda x: print_agent_output(x, "Info Researcher Agent"),
        )

    def claims_validation_agent(self):
        return Agent(
            role="Claims Validator Agent",
            goal="""take in a claim from a human, the category
            that the categorizer agent gave it and the analysis from the research agent and
            tell if its a valid claim or not also write a helpful reason for it in a friendly way.
            Validate claims in the following validation categories:
            
            valid_claim - used when the claim is valid and is eligible of the claim under the policy terms
            not_valid_claim - used when the claim is not valid and is not eligible of the claim under the policy terms 
                
            You never make up information. that hasn't been provided by the researcher or in the claim itself.
            Always sign off the claims in appropriate manner and from Wajid the Manager.
            """,
            backstory=""" You are a master at synthesizing a variety of information and a vigilant validator who ensures that claims meet policy conditions 
            and tell if a received claim is valid or not effectively and reply within 60 seconds""",
            # tools=[SearchTools.search_internet], # utilize builtin tools
            verbose=True,
            allow_delegation=False,
            max_iter=5,
            memory=True,
            step_callback=lambda x: print_agent_output(x, "Claim Validator Agent"),
        )

    # def claims_analysis_agent(self):
    #     return Agent(
    #         role="Claims Analyzer",
    #         goal="Analyze claims data to identify trends, patterns, and potential fraud",
    #         backstory="A detail-oriented analyst who excels at examining claims data, identifying anomalies, and providing insights for informed decision-making",
    #         verbose=True,
    #         allow_delegation=False,
    #         # tools=[search_tool],
    #     )

    # def claims_validation_agent(self):
    #     return Agent(
    #         role="Claims Validator",
    #         goal="""Verify the authenticity of the information and the eligibility of
    #         the claim under the policy terms""",
    #         backstory="""A vigilant validator who ensures that claims meet policy conditions
    #         before further processing""",
    #         # tools=[SearchTools.search_internet], # utilize builtin tools
    #         verbose=True,
    #         allow_delegation=True,
    #     )

    def employee_recommendation_agent(self):
        return Agent(
            role="Employee Recommender",
            goal="""Take in a claim document from a human that has been categorized by categorizer agent
            You will recommend employees for claims processing based on their expertise and workload you received in word document tool.""",
            backstory="""A knowledgeable recommender who understands the strengths and weaknesses of each claim 
            adjuster, ensuring the right person is assigned to each claim and reply within 60 seconds""",
            verbose=True,
            allow_delegation=False,
            max_iter=5,
            # memory=True,
            tools=[doc_tool],
        )
