## Import required libraries


## Append project directoty path
import sys

sys.path.append(
    "G:\My Drive\AI_Lead\Research_N_Development\CrewAI\CrewAI\CrewAI_Research\crewai_main"
)

from tools.manage_prompts import Prompts
from tools.model_response_processing_tool import (
    ModelResponseProcessing,
)
from tools.model_output_saviour_tool import OutputSaver
from tools.document_rag_tool import DocumentRag

# from tools.search_tools import SearchTools
# from tools.agent_output_tool import print_agent_output

# from langchain.agents import Tool
# from langchain.agents import load_tools

# os.environ["OPENAI_API_KEY"] = (
#     "testing_dummy_key"  # sk-proj-2mgLnO3sHblJ6VGFtCJET3BlbkFJ9hH85WziIXIkWMtH0w3Q
# )


class AIClaimSingleAgent:

    def __init__(self, *args, **kwargs):
        self.model = kwargs.get("model", None)
        self.claim_content = kwargs.get("claim_content", None)
        self.database_object = kwargs.get("database_object", None)
        self.model_name = kwargs.get("model_name", None)
        self.document_db_root_path = kwargs.get("document_db_root_path", None)

        prompts_obj = Prompts("single_agent_prompts")  ## prompt object
        self.prompts = prompts_obj.load_prompts()
        self.response_processing_obj = ModelResponseProcessing()
        self.output_saver_object = OutputSaver(
            self.model_name, self.claim_content, self.database_object
        )
        self.rag_tool_obj = DocumentRag()

    def single_agent_main(self):

        rag_agent_data = None  ## Require rag agent data or not

        # Categorizer agent
        ## Get received content's category
        categorizer_output = self.categorizer_agent()
        print("Category found: {}".format(categorizer_output.get("claim_type")))

        ##Summarization agent
        print("\nInitiating Summarization agent...")
        ## Get received case summary
        summarizer_output = self.summarizer_agent(
            categorizer_output.get("claim_type"), rag_agent_data
        )
        print("Case summary: {}".format(summarizer_output.get("summary")))

        ##Validator agent
        print("\nInitiating Validator agent...")

        # Get insurance validation file
        rag_validation_data = self.rag_tool_obj.extract_word_data(
            self.document_db_root_path + "Rules_Validations\Validation_Rules.docx"
        )

        ## Get received case validations
        validator_output = self.validator_agent(
            "auto_insurance_claim", rag_validation_data
        )  ## categorizer_output.get("claim_type") ##testing change
        print("Case validations: {}".format(validator_output.get("validation")))

        return f"Final outputs: Category: {summarizer_output}, \nCase summary: {summarizer_output}\nValidations: {validator_output}"

    def model_inference(self, prompt):

        try:
            prompt = [prompt]
            response = self.model.generate(prompt)

        except Exception as e:
            print("An error occurred during single claim process:", str(e))
            return ""

        return response.generations[0][0].text

    def categorizer_agent(self):

        agent_name = "single_agent_categorizer"

        # load categorizer prompts
        categorizer_prompts = self.prompts.get("categorizer_prompts")

        # Replace the placeholder with the question
        categorizer_prompt_1 = categorizer_prompts[0].format(
            claim_content=self.claim_content, database_object=self.database_object
        )

        response = self.model_inference(categorizer_prompt_1)

        if not response:
            print("\nNo response received from model inference!")
            response = ""

        ## Response preprocessing
        results = self.response_processing_obj.process_response(agent_name, response)

        ## save reponse and results
        self.output_saver_object.save_agent_output(agent_name, results)

        return results

    def summarizer_agent(self, category, rag_agent_data=None):

        agent_name = "single_agent_summarizer"
        category = category.replace("_", " ")

        # load summarizer prompts
        summarizer_prompts = self.prompts.get("summarizer_prompts")

        # Replace the placeholder with the question
        summarizer_prompt_1 = summarizer_prompts[0].format(
            category=category,
            claim_content=self.claim_content,
            database_object=self.database_object,
        )

        response = self.model_inference(summarizer_prompt_1)

        if not response:
            print("\nNo response received from model inference!")
            response = ""

        ## Response preprocessing
        results = self.response_processing_obj.process_response(agent_name, response)

        ## save reponse and results
        self.output_saver_object.save_agent_output(agent_name, results)

        return results

    def validator_agent(self, category, rag_validation_data=""):
        agent_name = "single_agent_validator"
        category = category.replace("_", " ")
        rag_validation_data = str(rag_validation_data)

        # load validator prompts
        validator_prompts = self.prompts.get("validator_prompts")

        # Replace the placeholder with the question
        validator_prompt_1 = validator_prompts[0].format(
            category=category,
            database_object=self.database_object,
            rag_validation_data=rag_validation_data,
        )

        response = self.model_inference(validator_prompt_1)

        if not response:
            print("\nNo response received from model inference!")
            response = ""

        ## Response preprocessing
        results = self.response_processing_obj.process_response(agent_name, response)

        ## save reponse and results
        self.output_saver_object.save_agent_output(agent_name, results)

        return results

    # def employee_recommender_agent(self, category, rag_agent_data="adjuster list"):
